library(testthat)
library(DiagrammeR)

test_check("DiagrammeR")
