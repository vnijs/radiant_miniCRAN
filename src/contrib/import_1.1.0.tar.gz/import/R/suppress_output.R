suppress_output <- function(e) suppressPackageStartupMessages(e)
