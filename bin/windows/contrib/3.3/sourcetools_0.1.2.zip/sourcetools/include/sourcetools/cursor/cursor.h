#ifndef SOURCE_TOOLS_CURSOR_CURSOR_H
#define SOURCE_TOOLS_CURSOR_CURSOR_H

#include <sourcetools/cursor/TextCursor.h>
#include <sourcetools/cursor/TokenCursor.h>

#endif /* SOURCE_TOOLS_CURSOR_CURSOR_H */
